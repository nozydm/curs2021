<?php

include("contrologin.php");

?>

aquesta és la privada3